#!/usr/bin/env node

var fs = require('fs');
var unzip = require('unzip');
var ldcZip = 'ldc.zip';
var ldcZipUpdate = ldcZip + '.update';

new Promise(function (resolve, reject) {
    fs.exists(ldcZipUpdate, function (exists) {
        if (!exists) {
            fs.writeFile(ldcZipUpdate, '', function (err) {
                resolve();
            });
        } else {
            resolve();
        }
    });
}).then(function () {
    fs.exists(ldcZip, function (exists) {
        if (!exists) return start();
        fs.stat(ldcZip, function (err, stats) {
            if (err) return start();
            fs.stat(ldcZipUpdate, function (err, updateStats) {
                if (err) return start();
                if (Math.abs(stats.mtime.getTime() - updateStats.mtime.getTime()) < 1000) {
                    console.log('no update.');
                    return start();
                }
                console.log('has update. unzipping...');
                fs.createReadStream(ldcZip).pipe(unzip.Extract({ path: 'extracted/' }))
                    .on('close', function () {
                        //                            fs.unlink(ldcZip, function (err) {
                        console.log('unzip done. update ldc.zip.update mtime.');
                        fs.utimes(ldcZipUpdate, stats.atime, stats.mtime, start);
                        //                            });
                    })
                    .on('error', function (err) {
                        console.error(err);
                    });
            });
        });
    });
});

function start() {
    var path = require('path');
    var Base64 = require('js-base64').Base64;

    var mpjServerRootURL = process.env.mpjServerRootURL;
    var mpjStoreId = process.env.mpjStoreId;
    var mpjOptions = process.env.mpjOptions;

    var mpjStartParam = process.env.mpjStartParam;
    var args = [];
    var exec = path.basename(process.argv[0], '.exe');
    if (exec.length >= 2 && exec.substr(0, 2).toLowerCase() == 'jx') {
        args = process.argv.splice(2);
    } else if (exec.length >= 4 && exec.substr(0, 4).toLowerCase() == 'node') {
        args = process.argv.splice(2);
    } else {
        args = process.argv.splice(1);
    }

    if (args.length > 1) {
        mpjServerRootURL = args[0];
        mpjStartParam = args[1];
    }

    function isJSON(str) {
        return str.substr(0, 1) == "{" && str.substr(str.length - 1, 1) == "}";
    }

    function isBase64(str) {
        return str.length > 7 ? str.substr(0, 7) == 'base64/' : str;
    }

    if (mpjStartParam) {
        mpjStoreId = mpjStartParam;
        if (isBase64(mpjStartParam)) {
            mpjStartParam = Base64.decode(mpjStartParam.substr(7));
            mpjStoreId = mpjStartParam;
        }
        if (isJSON(mpjStartParam)) {
            mpjOptions = JSON.parse(mpjStartParam);
            mpjStoreId = mpjOptions.storeId;
            delete mpjStoreId.storeId;
        }
    }

    console.log("process.env.mpjOptions:         +++++++++++", mpjOptions);
    if (mpjOptions) {
        if (mpjOptions.option && mpjOptions.option.info && mpjOptions.option.info.services.fns === "on") {
            console.log("mpjStoreId:", mpjStoreId);
            try {
                var fnsconfig = require("./extracted/fns/appconfig.js");
                fnsconfig.port = 8897;
                fnsconfig.storeId = mpjStoreId;

                var FrontNotifyServer = require("./extracted/fns/frontNotifyServer.js");
                var fns = new FrontNotifyServer.FrontNotifyServer(fnsconfig);
                fns.Start();
            }
            catch (err) {
                console.log("fns 启动失败：", err);
            }
        }
    }

    if (mpjServerRootURL && mpjStoreId) {
        process.env.path += ';' + path.normalize(process.cwd() + '/..');
        process.env.mpjServerRootURL = mpjServerRootURL;
        process.env.mpjStoreId = mpjStoreId;
        if (mpjOptions) {
            process.env.mpjOptions = JSON.stringify(mpjOptions);
        }
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
        require('forever').start('extracted/server.js', {});
    } else {
        console.log('没有提供mpjServerRootURL和mpjStoreId,中止启动');
        console.log('这两个值可通过参数或环境变量进行配置');
        console.log('参数配置：第一个参数是mpjServerRootURL，mpjStoreId');
    }
}